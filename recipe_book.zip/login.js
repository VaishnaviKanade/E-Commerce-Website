function login() {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    alert(`Logged in with username: ${username}`);
}

function loginWithGoogle() {
    alert('Logging in with Google');
}

function loginWithLinkedIn() {
    alert('Logging in with LinkedIn');
}

function loginWithFacebook() {
    alert('Logging in with Facebook');
}

// Add a function to redirect to the next page
function redirectToHome() {
    window.location.href = 'index.html';
}

function login() {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    // Implement your login logic here
    // For simplicity, let's just show an alert and then redirect
    alert(`Logged in with username: ${username}`);
    
    // Redirect to the home page
    redirectToHome();
}

// ... (existing code)
