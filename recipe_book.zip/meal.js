document.addEventListener('DOMContentLoaded', function () {
    // ... (existing code)

    // Function to handle day selection
    function selectDay(day) {
        const selectedDay = document.querySelector('.selected-day');
        if (selectedDay) {
            selectedDay.classList.remove('selected-day');
        }

        const dayElement = document.getElementById(day);
        if (dayElement) {
            dayElement.classList.add('selected-day');
        }
    }

    // Add click event listeners to each day
    days.forEach(day => {
        const dayElement = document.getElementById(day);
        if (dayElement) {
            dayElement.addEventListener('click', () => selectDay(day));
        }
    });

    // ... (existing code)
    
});
