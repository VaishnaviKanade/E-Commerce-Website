function register() {
    const username = document.getElementById('username').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    // Implement your registration logic here
    // For simplicity, let's just show an alert and then redirect to the login page
    alert(`Registered with username: ${username}, email: ${email}`);
    
    // Redirect to the login page
    window.location.href = 'login.html';
}
