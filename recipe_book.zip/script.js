document.addEventListener('DOMContentLoaded', function () {
    // Sample recipe data (you can replace this with dynamic data from a server)
    const recipes = [
        { title: 'Spaghetti Bolognese', ingredients: ['Pasta', 'Tomato Sauce', 'Ground Beef'], },
        { title: 'Chicken Stir Fry', ingredients: ['Chicken', 'Vegetables', 'Soy Sauce'], },
        { title: 'Vegetarian Pizza', ingredients: ['Pizza Dough', 'Tomato Sauce', 'Cheese', 'Vegetables'], },
        { title: 'Grilled Salmon', ingredients: ['Salmon', 'Lemon', 'Garlic', 'Herbs'], },
        { title: 'Caprese Salad', ingredients: ['Tomatoes', 'Fresh Mozzarella', 'Basil', 'Balsamic Glaze'], },
        { title: 'Chocolate Chip Cookies', ingredients: ['Flour', 'Butter', 'Sugar', 'Chocolate Chips'], },
        { title: 'Avocado Toast', ingredients: ['Avocado', 'Bread', 'Salt', 'Pepper'], },
        { title: 'Vegetable Curry', ingredients: ['Mixed Vegetables', 'Curry Sauce', 'Rice'], },
        // Add more recipes as needed
    ];

    const recipeList = document.getElementById('recipeList');

    // Populate recipe cards in the meal planner
    recipes.forEach(recipe => {
        const card = document.createElement('div');
        card.className = 'recipeCard';
        card.innerHTML = `
            <h3>${recipe.title}</h3>
            <ul>${recipe.ingredients.map(ingredient => `<li>${ingredient}</li>`).join('')}</ul>
        `;
        recipeList.appendChild(card);
    });
});
