document.addEventListener('DOMContentLoaded', function () {
    // Sample recipe data (you can replace this with dynamic data from a server)
    const recipes = [
        { title: 'Spaghetti Bolognese', ingredients: ['Pasta', 'Tomato Sauce', 'Ground Beef'], },
        { title: 'Chicken Stir Fry', ingredients: ['Chicken', 'Vegetables', 'Soy Sauce'], },
        { title: 'Vegetarian Pizza', ingredients: ['Pizza Dough', 'Tomato Sauce', 'Cheese', 'Vegetables'], },
        { title: 'Grilled Salmon', ingredients: ['Salmon', 'Lemon', 'Garlic', 'Herbs'], },
        { title: 'Caprese Salad', ingredients: ['Tomatoes', 'Fresh Mozzarella', 'Basil', 'Balsamic Glaze'], },
        { title: 'Chocolate Chip Cookies', ingredients: ['Flour', 'Butter', 'Sugar', 'Chocolate Chips'], },
        { title: 'Avocado Toast', ingredients: ['Avocado', 'Bread', 'Salt', 'Pepper'], },
        { title: 'Vegetable Curry', ingredients: ['Mixed Vegetables', 'Curry Sauce', 'Rice'], },
        // Add more recipes as needed
    ];

    const recipeList = document.getElementById('recipeList');
    const days = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];

    // Populate recipe cards in the meal planner
    recipes.forEach((recipe, index) => {
        const card = document.createElement('div');
        card.className = 'recipeCard';
        card.draggable = true;
        card.id = `recipe${index}`;
        card.innerHTML = `
            <h3>${recipe.title}</h3>
            <ul>${recipe.ingredients.map(ingredient => `<li>${ingredient}</li>`).join('')}</ul>
        `;
        recipeList.appendChild(card);
    });

    // Function to allow dropping on days and meal options
    window.allowDrop = function (event) {
        event.preventDefault();
    }

    // Function to handle dragstart event
    window.drag = function (event) {
        event.dataTransfer.setData('text', event.target.id);
    }

    // Function to handle drop event
    // window.drop = function (event) {
    //     event.preventDefault();
    //     const data = event.dataTransfer.getData('text');
    //     const draggedElement = document.getElementById(data);

    //     // Append the dragged element to the drop zone
    //     event.target.appendChild(draggedElement);
        
    //     // If dropped into a day, update the day text
    //     if (days.includes(event.target.id)) {
    //         event.target.textContent = `${event.target.id.charAt(0).toUpperCase()}${event.target.id.slice(1)}`;
    //     }
    // };
    // Function to handle drop event
window.drop = function (event) {
    event.preventDefault();
    const data = event.dataTransfer.getData('text');
    const draggedElement = document.getElementById(data);

    // If dropped into a day, find the drop zone and append the dragged element to it
    if (days.includes(event.target.id)) {
        const dropZone = event.target.querySelector('.dropzone');
        dropZone.appendChild(draggedElement);
        event.target.textContent = `${event.target.id.charAt(0).toUpperCase()}${event.target.id.slice(1)}`;
    } else {
        // If dropped into a meal option, append to the drop zone directly
        event.target.appendChild(draggedElement);
    }
};



});


